package autolog.core;

import java.util.ArrayList;

public class User {
	
	private int ID;
	private String username;
	private String password;
	private ArrayList<Vehicle> vehicleList;
	
	User(String username, String password) {
		super();
	}
	
	public int getID() {
		return this.ID;
	}
	
	public void setID(int id) {
		this.ID = id;
	}
	
	public String getUsername() {
		return this.username;
	}
	
	public void setID(String uname) {
		this.username = uname;
	}
	
	public String getPassword() {
		return this.password;
	}
	
	public void setPassword(String pass) {
		this.password = pass;
	}
	
	public ArrayList<Vehicle> getVechicleList() {
		return this.vehicleList;
	}
	
}
