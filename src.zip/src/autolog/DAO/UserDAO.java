package autolog.DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class UserDAO extends DataBaseDAO {
	
	private Connection con;
    private Statement st;
    private ResultSet rs;
	
	public UserDAO() { 
        // TODO: Should initialize 'con', probably
    }
	
	 /**
     * authenticates user if username and password are correct
     * 
     * @param String username of user
     * @param String password of the user
     * @return Boolean true if credentials are accurate. False if not
     */
    public boolean isAuthenticated(String username, String password) {
    	con = getConnection();
    	
     	boolean authenticated = false;
     	try {
            Statement stmt = con.createStatement();
            try {
                String query = "select exists(select * from user where username='" + username + "' and password='" + password +"')";
                ResultSet rs = stmt.executeQuery(query);
      
                authenticated = rs.getBoolean(1);
               
            } finally {
                try { stmt.close(); } catch (Exception ignore) {}
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
            try { con.close(); } catch (Exception ignore) {}
        }
     	return authenticated;
    }
}
