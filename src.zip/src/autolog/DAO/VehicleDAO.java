package autolog.DAO;

import java.sql.*;
import java.util.ArrayList;

import autolog.core.Vehicle;


public class VehicleDAO extends DataBaseDAO {
	private Connection con;
    private Statement st;
    private ResultSet rs;
    private Vehicle v;

    public VehicleDAO() { 
        // TODO: Should initialize 'con', probably
    }
    
    public Vehicle getVehicle(int ID, int userID) {
    	//if (con.isClosed() || con == null) {
		con = getConnection();
		//}
    	v = new Vehicle(0, 0, null, null, 0, 0);
    	try {
            st = con.createStatement();
            try {
                String query = "select * from vehicle where ID='" + ID + "' and " + "userID= '" + userID + "'";
                rs = st.executeQuery(query);
      
                try {
             	   //ResultSetMetaData rsmd = rs.getMetaData();
             	   System.out.println(query);
                         //int columnsNumber = rsmd.getColumnCount();
                                 int id = rs.getInt(1);
                                 v.setID(id);
 
                                 int uID = rs.getInt(2);
                                 v.setUserID(uID);
                                 
                                 String make = rs.getString(4);
                                 v.setMake(make);
                                 
                                 String model = rs.getString(5);
                                 v.setModel(model);
                                 
                                 int year = rs.getInt(6);
                                 v.setYear(year);
                                 
                                 int mileage = rs.getInt(7);
                                 v.setMileage(mileage);
                                 
                } finally {
                try { rs.close(); } catch (Exception ignore) {}
                }
               
            } finally {
                try { st.close(); } catch (Exception ignore) {}
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
			// TODO Auto-generated catch block
			e.printStackTrace();
        } 
    	closeConnection();
    	return v;
    }


    public ArrayList<Vehicle> selectAllVehicles(int userID) throws SQLException {
    	ArrayList vehicleList = new ArrayList<Vehicle>();
    	
    	con = getConnection();
    	
    	try {
            st = con.createStatement();
            try {
                String query = "select * from vehicle where userID='" + userID + "'";
                rs = st.executeQuery(query);
                try {
                	   ResultSetMetaData rsmd = rs.getMetaData();
                	   System.out.println(query);
                            int columnsNumber = rsmd.getColumnCount();
                            while (rs.next()) {
                                for (int i = 1; i <= columnsNumber; i++) {
                                    if (i > 1) System.out.print(",  ");
                                    String columnValue = rs.getString(i);
                                    System.out.print(rsmd.getColumnName(i) + "=" + columnValue);
                                }
                                System.out.println("");
                            }
                } finally {
                    try { rs.close(); } catch (Exception ignore) {}
                }
            } finally {
                try { st.close(); } catch (Exception ignore) {}
            }
        } finally {
            try { closeConnection(); } catch (Exception ignore) {}
        }
    	return vehicleList;
    }
}
